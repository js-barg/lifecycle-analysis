import LifecyclePage from './components/LifecyclePage'

function App() {
  return <LifecyclePage />
}

export default App